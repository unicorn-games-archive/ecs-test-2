import Entity from "./Entity.js"
import {
  Appearance,
  PhysicsVelocity,
  PhysicsMass,
  PhysicsCollider,
  Transform,
} from "./components/index.js"

export default function TestEntity(positionX) {
  return new Entity({
    components: [
      Appearance,
      PhysicsVelocity,
      PhysicsMass,
      PhysicsCollider,
      Transform,
    ],

    initialState: {
      appearance: {
        colors: {
          r: 0,
          g: 150,
          b: 255,
        },
        shape: "circle"
      },

      transform: {
        position: {
          x: positionX,
          y: window.innerHeight - window.innerHeight/2
        },
        scale: 20
      },

      physicsVelocity: {
        x: 0,
        y: 0
      },

    }
  })
}