import Entity from "./Entity.js"
import {
  Appearance,
  PhysicsVelocity,
  PhysicsMass,
  Transform,
  TouchControlLeftRight
} from "./components/index.js"

export default function PlayerCharacter() {
  return new Entity({
    props: ["gameOver"],

    components: [
      Appearance,
      PhysicsVelocity,
      PhysicsMass,
      Transform,
      TouchControlLeftRight,
    ],

    initialState: {
      appearance: {
        colors: {
          r: 255,
          g: 0,
          b: 0,
        },
        shape: "square"
      },

      transform: {
        position: {
          x: window.innerWidth/2,
          y: window.innerHeight
        },
        scale: 1
      },

    },

  })
}