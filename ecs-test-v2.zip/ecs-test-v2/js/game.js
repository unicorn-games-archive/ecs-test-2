import * as Systems from "./systems/index.js"

window.ECS = {
  Components: {},

  systems: {},
  entities: [],
  game: {},

  score: 0
};

ECS.$canvas = document.getElementById("game-canvas");
ECS.$canvas.width = window.innerWidth;
ECS.$canvas.height = window.innerHeight;
ECS.context = ECS.$canvas.getContext("2d");

import PlayerCharacter from "./PlayerCharacter.js"
import TestEntity from "./TestEntity.js"

function Game () {
  var self = this;

  // Create some entities
  // ----------------------------------
  var entities = {}; // object containing { id: entity  }

  const playerEntity = PlayerCharacter();
  //const testEntity = TestEntity();

  [
    TestEntity(window.innerWidth/2 - 100),
    TestEntity(window.innerWidth/2 - 50),
    TestEntity(window.innerWidth/2 + 50),
    TestEntity(window.innerWidth/2 + 100),
  ].forEach(entity => entities[entity.id] = entity)

  entities[playerEntity.id] = playerEntity;
  //entities[testEntity.id] = testEntity;

  ECS.entities = entities;

  const systems = [
    Systems.UserInput(ECS.entities),
    Systems.TouchControlLeftRightSystem(ECS.entities),
    Systems.TouchControlDragSystem(ECS.entities),
    Systems.Collision(ECS.entities),
    Systems.Gravity(ECS.entities),
    Systems.Physics(ECS.entities),
    Systems.Render(ECS.entities)
  ];

  function gameLoop () {
    for (var i = 0, len = systems.length; i < len; i++) {
      if (typeof systems[i] == "function") systems[i]();
    }

    if (self._running !== false) {
      requestAnimationFrame(gameLoop);
    }
  }
  // Kick off the game loop
  requestAnimationFrame(gameLoop);

  // Lose condition
  // ----------------------------------
  this._running = true; // is the game going?
  this.endGame = function endGame() {
    self._running = false;
    console.log("game over");

    // set a small timeout to make sure we set the background
    setTimeout(function() {
      document.getElementById('game-canvas').className = 'game-over';
    }, 100);
  };


  return this;
};

// Kick off the game
ECS.game = new Game();