import createSystem from "../createSystem.js"

export default createSystem("TouchControlLeftRightSystem",
  ["touchControlLeftRight"],

  // TODO: move the systemFunction argument to the lifecycleHooks argument and rename it to "onUpdate"
  () => {},

  {
    mounted:
    entities => entities.forEach(({
      components
    }) => {
      document.addEventListener("touchstart",
        event => updateComponentsDataOnTouch(components, getDirectionFromTouch(event)));
    })
  })

  function updateComponentsDataOnTouch(components, touchDirection) {
    Object.entries(components.touchControlLeftRight[touchDirection]).forEach(([key,
      value]) => {
      components[key] = {
        ...value
      }
    })
  }

  function getDirectionFromTouch(event) {
    let direction = null;
    const {
      clientX
    } = event.touches[0];

    if (clientX < (window.innerWidth/ 2)) {
      direction = "left";
    } else {
      direction = "right";
    }

    return direction;
  }