import createSystem from "../createSystem.js"

export default createSystem("Physics",
  ["transform", "physicsVelocity"],
  entities => entities.forEach(({
    components
  }) => {
    components.transform.position.x += components.physicsVelocity.x
    components.transform.position.y += components.physicsVelocity.y

    // TODO: move all of this in a parent component
    if (components.transform.position.x < 0) {
      components.transform.position.x = 0
    }

    if (components.transform.position.x > window.innerWidth
    ) {
      components.transform.position.x = window.innerWidth
    }

    if (components.transform.position.y < 0) {
      components.transform.position.y = 0
      components.physicsVelocity.y = 0
    }

    if (components.transform.position.y > window.innerHeight) {
      components.transform.position.y = window.innerHeight
      components.physicsVelocity.y = 0
      components.physicsVelocity.x = 0
    }

  })
)