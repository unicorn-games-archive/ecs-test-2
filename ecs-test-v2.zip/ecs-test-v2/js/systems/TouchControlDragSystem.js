import createSystem from "../createSystem.js"

export default createSystem("TouchControlDragSystem",
  ["touchControlDrag"],

  // TODO: move the systemFunction argument to the lifecycleHooks argument and rename it to "onUpdate"
  () => {},

  {
    mounted:
    entities => entities.forEach(({
      components
    }) => {

      document.addEventListener("touchmove",
        event => updatePositionDataOnTouch(components, event))

      if (components.physicsVelocity) {
        document.addEventListener("touchstart", event => {
          
          updatePositionDataOnTouch(components, event)
        })
        document.addEventListener("touchend",
          event => {})
      }

    })
  })

  function updatePositionDataOnTouch(components, event) {
    if (components.physicsVelocity) components.physicsVelocity = {
            x: 0,
            y: 0
          }
          
    components.transform.position = {
      x: event.touches[0].clientX,
      y: event.touches[0].clientY
    }
  }