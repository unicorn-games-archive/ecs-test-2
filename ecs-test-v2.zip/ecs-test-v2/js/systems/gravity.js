import createSystem from "../createSystem.js"

export default createSystem("Gravity",
  ["physicsMass"],
  entities => entities.forEach(({
    components
  }) => {
    components.physicsVelocity.y += 0.2
  })
)