import createSystem from "../createSystem.js"

export default createSystem("Render",
  ["appearance", "transform"],
  entities => {
    clearCanvas();
    entities.forEach(entity => {
      if (entity.components.appearance.shape == "circle") {
        drawCircle(entity)
      }
    })
  }
)

  function clearCanvas () {
    // Store the current transformation matrix
    ECS.context.save();

    // Use the identity matrix while clearing the canvas
    ECS.context.setTransform(1, 0, 0, 1, 0, 0);
    ECS.context.clearRect(0, 0, ECS.$canvas.width, ECS.$canvas.height);

    // Restore the transform
    ECS.context.restore();
  }

  function drawCircle(curEntity) {
    ECS.context.beginPath();
    ECS.context.arc(curEntity.components.transform.position.x, curEntity.components.transform.position.y, curEntity.components.transform.scale, 0, 2 * Math.PI);

    ECS.context.fillStyle = 'rgba(' + [
      curEntity.components.appearance.colors.r,
      curEntity.components.appearance.colors.g,
      curEntity.components.appearance.colors.b
    ] + ',1)';
    ECS.context.fill();

    ECS.context.strokeStyle = 'rgba(0,0,0,1)';
    ECS.context.lineWidth = 5;
    ECS.context.stroke();
  }