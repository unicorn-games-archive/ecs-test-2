export default function Entity( {
  components, initialState
}) {
  // Generate a pseudo random ID
  this.id = (+new Date()).toString(16) +
  (Math.random() * 100000000 | 0).toString(16) +
  Entity.prototype._count;

  // increment counter
  Entity.prototype._count++;

  // The component data will live in this object
  this.components = {};

  for (const idx in components) {
    const component = components[idx]
    let name = component.name.charAt(0).toLowerCase() + component.name.slice(1)
    this.addComponent(component, initialState[name])
  }

  return this;
};
  // keep track of entities created
  Entity.prototype._count = 0;

  Entity.prototype.addComponent = function addComponent (component, initialState) {

    let name = component.name.charAt(0).toLowerCase() + component.name.slice(1)
    this.components[name] = new component(initialState || null);

    return this;
  };

  Entity.prototype.removeComponent = function removeComponent (componentName) {
    var name = componentName;

    if (typeof componentName === 'function') {
      name = componentName.prototype.name;
    }

    delete this.components[name];
    return this;
  };

  Entity.prototype.print = function print () {
    console.log(JSON.stringify(this, null, 4));
    return this;
  };