import Entity from "./Entity.js"
import {
  Appearance,
  PhysicsVelocity,
  PhysicsMass,
  PhysicsCollider,
  Transform,
  TouchControlDrag,
} from "./components/index.js"

export default function PlayerCharacter() {
  return new Entity({
    components: [
      Appearance,
      PhysicsVelocity,
      PhysicsMass,
      PhysicsCollider,
      Transform,
      TouchControlDrag,
    ],

    initialState: {
      appearance: {
        colors: {
          r: 0,
          g: 255,
          b: 0,
        },
        shape: "circle"
      },

      transform: {
        position: {
          x: window.innerWidth/2,
          y: window.innerHeight - window.innerHeight/2
        },
        scale: 20
      },

      physicsVelocity: {
        x: 0,
        y: 0
      }

    }
  })
}