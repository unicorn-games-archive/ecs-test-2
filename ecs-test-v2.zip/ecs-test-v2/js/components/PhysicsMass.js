import createComponent from "../createComponent.js"

export default createComponent("PhysicsMass", {
  mass: 1
})