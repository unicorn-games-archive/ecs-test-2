import createComponent from "../createComponent.js"

export default createComponent("PhysicsVelocity", {
  x: 0,
  y: 0
})