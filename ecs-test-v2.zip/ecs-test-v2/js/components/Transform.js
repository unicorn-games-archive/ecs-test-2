import createComponent from "../createComponent.js"

export default createComponent("Transform", {
  position: {
    x: 0, y: 0
  },
  rotation: 0,
  scale: 10
})