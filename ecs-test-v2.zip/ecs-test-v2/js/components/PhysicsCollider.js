import createComponent from "../createComponent.js"

export default createComponent("PhysicsCollider", {
  isCollidable: 1
})