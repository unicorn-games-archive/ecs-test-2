import createComponent from "../createComponent.js"

export default createComponent("Appearance", {
  shape: "circle",
  colors: {
    r: 255,
    g: 255,
    b: 255,
  }
})