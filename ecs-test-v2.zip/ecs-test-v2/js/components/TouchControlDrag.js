import createComponent from "../createComponent.js"

export default createComponent("TouchControlDrag", {
  useEntireCanvas: false
})