import createComponent from "../createComponent.js"

export default createComponent("TouchControlLeftRight", {
  left: null,
  right: null
})