export default function createComponent(name, fields) {
  const Component = class {
    constructor(props) {
      // assign props to existing component fields
      if (typeof props == "object") {
        for (const field in props) {
          if (typeof this[field] != "undefined") {
            this[field] = props[field]
          } else {
            throw new Error(`Field "${field}" does not exist in ${name}.`)
          }
        }
      }

      // report undefined fields
      for (const field in this) if (typeof this[field] == "undefined") throw new Error(`Undefined field "${field}" in ${PhysicsComponent.name}.`)
    }
  }

  // define component fields from props
  for (const field in fields) {
    Component.prototype[field] = fields[field]
  }

  Object.defineProperty (Component, 'name', {
    value: name
  });

  return Component
}