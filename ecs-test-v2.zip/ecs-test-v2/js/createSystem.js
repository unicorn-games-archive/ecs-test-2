export default function createSystem(name, componentNames, systemFunction, lifecycleHooks) {
  return entities => {

    // filter entities by component name
    const filteredEntities = Object
    .values(entities)
    .filter(entity => componentNames
      .every(componentName => Object
        .keys(entity.components)
        .includes(componentName)
      )
    )

    if (lifecycleHooks) {
      console.log("aaa", filteredEntities)
      lifecycleHooks.mounted(filteredEntities)
    }

    return () => systemFunction(filteredEntities)
  }
}